"""
URL configuration for monitoramento project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
"""
URL configuration for monitoramento project.
"""

from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('app.urls')),
    
    # Rota de Autenticação JWT (Esta é a rota correta para obter o Token de Acesso)
    path('api/auth/', include('djoser.urls')), 
    path('api/auth/', include('djoser.urls.jwt')), # Chaves: /jwt/create/, /jwt/refresh/, /jwt/verify/
    
    path('api-auth/', include('rest_framework.urls')),
]
